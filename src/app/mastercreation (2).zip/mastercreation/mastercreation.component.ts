import { Component, OnInit, OnDestroy, ChangeDetectorRef } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd, NavigationStart } from '@angular/router';
import { Subscription } from 'rxjs';
import { AuthService } from '../auth.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-mastercreation',
  templateUrl: './mastercreation.component.html',
  styleUrls: ['./mastercreation.component.sass']
})
export class MastercreationComponent implements OnInit, OnDestroy {
  selectedView: string = 'create-university';
  public isLoading: boolean = false;
  private routeSubscription: Subscription;
  loggedUser: any = {};
  userData: any;
  myDate: Date = new Date();
  departmentslist: any[] = [];
  departmentslists: any[] = [];
  designationslist:any[]=[];
  designationslists:any[]=[];
  universityslist:any[]=[];
  businessunitList:any[]=[];
  universityForm: FormGroup;
  departmentForm:FormGroup;
  searchTermDesignation:any;
  designationForm:FormGroup;
  universitycheck:boolean=false;
  selectedUniversityName: string | null = null;
  // selectedBusinessUnitDesignation: string | null = ""; 
  // selectedBusinessUnit: string | null = ""; 
  selectedBusinessUnitDesignation: string | null = ""; 
  selectedBusinessUnit: string | null = ""; 
  isEditing: boolean = false;
  isDesignation:boolean=false;
  isDepartment:boolean=false;
  searchTermUniversity:any;
  searchTermDepartment:any;
  selectedUniversityId: any;
  selectedDesignationId:any;
  designationSearchAssign:any;
  departmentSearch:any;
  selectedDesignationName:any;
  selectedDesignationCode:any;
  selectedDesignationStatus:any;
  selectedDepartmentId:string;
  selectedDepartmentName:any;
  selectedDepartmentCode:any;
  selectedDepartmentStatus:any;
  universitySearch:any;
  designationSearch:any;
  searchTerm: any;
  searchTerms:any;
  searchTermAssignDepartment:any;
  empCode:any;
  departmentassignSearch:any;
  designationassignSearch:any;
  isBusinessUnitSelected: boolean = false; 
  isBusinessUnitDesignationSelected:boolean=false;
  selectedDepartments: any[] = []; 
  selectedDesignations:any[]=[];
 

  constructor(private fb: FormBuilder, private router: Router, private route: ActivatedRoute,private service:AuthService,private cdr: ChangeDetectorRef) {}

  ngOnInit(): void {
    this.routeSubscription = this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        this.setSelectedViewBasedOnRoute(this.router.url);
        this.universityForm.reset();
        this.departmentForm.reset();
        this.departmentForm.patchValue({
          status: ''  
        });
        this.designationForm.reset();
        this.designationForm.patchValue({
          status: ''  
        }); 
        this.selectedBusinessUnit = ''; 
        this.businessUnit();  
        this.departments();
        this.isBusinessUnitSelected=false
        this.selectedBusinessUnitDesignation='';
        this.designations();
        this.isBusinessUnitDesignationSelected=false;
      }
    });

    this.loggedUser = decodeURIComponent(window.atob(localStorage.getItem('userData')));
    this.userData = JSON.parse(this.loggedUser);
    let emp = [{ 'empID': "" + this.userData.user.empID + "" }];
    this.setSelectedViewBasedOnRoute(this.router.url);
    this.departments();
    this.designations();
    this.universitys();
    this.businessUnit();
    this.universityForm = this.fb.group({
      name: ['',Validators.required] 
    });
   
    this.departmentForm=this.fb.group({
      name: ['', Validators.required],
      code:['',Validators.required],
      status:['',Validators.required]
    });
    this.designationForm=this.fb.group({
      name: ['', Validators.required],
      code:['',Validators.required],
      status:['',Validators.required]
    });
  }

  ngOnDestroy(): void {
    if (this.routeSubscription) {
      this.routeSubscription.unsubscribe();
    }

  }
  setSelectedViewBasedOnRoute(url: string): void {
    if (url.includes('create-university')) {
      this.selectedView = 'create-university';
      this.resetFormAndFilters();
    } else if (url.includes('create-department')) {
      this.selectedView = 'create-department';
    } else if (url.includes('assign-department')) {
      this.selectedView = 'assign-department';
    } else if (url.includes('create-designation')) {
      this.selectedView = 'create-designation';
    } else if (url.includes('assign-designation')) {
      this.selectedView = 'assign-designation';
    }
  }
businessUnit(){
this.empCode=this.userData.user.empID;
const formData=new FormData();
formData.append('empCode',this.empCode);
this.service.getBusinessunit(formData).subscribe((res:any)=>{
  //console.log("busines"+res);
  this.businessunitList=res;
})
}
//departments assign
onBusinessUnitChange() {
  this.isBusinessUnitSelected = this.selectedBusinessUnit !== ''; 
  this.isBusinessUnitSelected = this.selectedBusinessUnit ? true : false;
  const formData = new FormData();
  formData.append("Businessunitid", this.selectedBusinessUnit); 
  this.service.assignDepartments(formData).subscribe((res: any) => {
    //console.log("Assigned Business Unit Departments:", res);
    this.departmentslist.forEach(dept => {
      const assignedDept = res.find((assigned: any) => assigned.departmentid === dept.departmentid);
      if (assignedDept) {
        dept.isChecked = true; 
        dept.businessunitid = assignedDept.businessunitid; 
      } else {
        dept.isChecked = false;
        dept.businessunitid = this.selectedBusinessUnit;
      }
    });
    this.updateCheckedDepartments();
  });
}
onCheckboxChange(department: any) {
  if (department.isChecked) {
    //console.log(this.selectedBusinessUnit + "--" + department.departmentid);
    department.status = 1001; 
    this.selectedDepartments.push(department);
  } else {
    //console.log(`Department ${department.departmentid} unchecked, updating status to 1002.`);
    department.status = 1002;  
    if (department.departmentid && department.businessunitid) {
      this.selectedDepartments.push(department);
    }
  }
  this.updateCheckedDepartments();
}
updateCheckedDepartments() {
  this.selectedDepartments = []; 
  this.departmentslist.forEach(dept => {
    if (dept.departmentid && dept.businessunitid) {
      if (dept.isChecked) {
        dept.status = 1001;  
      } else {
        dept.status = 1002; 
      }
      this.selectedDepartments.push(dept);  
    } else {
      //console.warn(`Skipping department ${dept.departmentid} with invalid data.`);
    }
  });

  const result = this.selectedDepartments.map(department => ({
    departmentid: department.departmentid,
    businessunitid: department.businessunitid,
    status: department.status,
    sectionid:department.sectionid,
    createdby:this.userData.user.empID
  }));

  //console.log("Updated selected departments:", result);
  return result;
}
onSubmit(result: any[]) {
  const invalidDepartments = result.filter(department => 
    !department.departmentid || !department.businessunitid || department.status <= 0
  );
  
  if (invalidDepartments.length > 0) {
    //console.error("Invalid departments found:", invalidDepartments);
    return;
  }
  if (this.selectedBusinessUnit && result.length > 0) { 
    
    this.isLoading = true;
    //console.log("Submitting result:", result); 
    this.service.assignDepartmentinsert(result).subscribe(
      (res: any) => {
        this.isLoading = false;
       // console.log("Departments  assign inserted successfully:", res);
        Swal.fire({
          title: 'Success!',
          text: 'Departments Assign successfully updated!',
          icon: 'success',
          confirmButtonText: 'OK',
        });
        this.departments();
        this.selectedDepartments = []; 
      },
      (error) => {
        //console.error("Error inserting department:", error);
        this.isLoading = false;
        Swal.fire({
          title: 'Error!',
          text: `Error inserting department.`,
          icon: 'error',
          confirmButtonText: 'OK',
        });
      }
    );
  } else {
    //console.error("Please select a Business Unit and at least one department.");
    this.isLoading = false;
    Swal.fire({
      title: 'Error!',
      text: `Please select a Business Unit and at least one department.`,
      icon: 'error',
      confirmButtonText: 'OK',
    });
  }
}
  departments(){
    this.service.getDepartments().subscribe((res:any)=>{
      this.departmentslist = res;
      this.departmentslists=res;
      this.departmentassignSearch = res;
      this.departmentSearch=res;
      if (this.selectedBusinessUnit) {
        ///console.log("selectedBusinessUnit"+this.selectedBusinessUnit)
        this.onBusinessUnitChange(); 
      }
    })
  }
  //designationassign
  designations(){
    this.service.getDesignations().subscribe((res:any)=>{
      this.designationslist = res;
      this.designationslists=res;
      this.designationSearch = res;
      this.designationSearchAssign=res;
      if (this.selectedBusinessUnitDesignation) {
        this.onBusinessUnitChangeDesignation(); 
      }
    })
  }
  onBusinessUnitChangeDesignation(){
    this.isBusinessUnitDesignationSelected = this.selectedBusinessUnitDesignation !== ''; 
    this.isBusinessUnitSelected = this.selectedBusinessUnitDesignation ? true : false;
    const formData = new FormData();
    formData.append("Businessunitid", this.selectedBusinessUnitDesignation); 
    this.service.assignDesignations(formData).subscribe((res: any) => {
      //console.log("Assigned Business Unit Designations:", res);
      this.designationslist.forEach(design => {
        const assignedDesignation = res.find((assigned: any) => assigned.designationid === design.designationid);
        if (assignedDesignation) {
          design.isChecked = true; 
          design.businessunitid = assignedDesignation.businessunitid; 
        } else {
          design.isChecked = false;
          design.businessunitid = this.selectedBusinessUnitDesignation;
        }
      });
      this.updateCheckedDesignations();
    });
  }
  onCheckboxChangeDesignation(designation: any) {
    designation.createdBy=12779;
    if (designation.isChecked) {
      //console.log(this.selectedBusinessUnitDesignation + "--" + designation.designationid);
      designation.status = 1001; 
      
      this.selectedDesignations.push(designation);
    } else {
      //console.log(`Designation ${designation.designationid} unchecked, updating status to 1002.`);
      designation.status = 1002;  
      if (designation.designtaionid && designation.businessunitid) {
        this.selectedDesignations.push(designation);
      }
    }
    this.updateCheckedDesignations();
  }
  updateCheckedDesignations() {
    this.selectedDesignations = []; 
    this.designationslist.forEach(design => {
        if (design.designationid && design.businessunitid) {
            if (design.isChecked) {
                design.status = 1001;  
            } else {
                design.status = 1002; 
            }
            // Set createdBy to 12779
            //design.createdBy = 12779;
            this.selectedDesignations.push(design);  
        } else {
            //console.warn(`Skipping designations ${design.designationid} with invalid data.`);
        }
    });

    const resultdesignations = this.selectedDesignations.map(designations => ({
        designationid: designations.designationid,
        businessunitid: designations.businessunitid,
        status: designations.status,
        createdBy: designations.createdBy,  // Add createdBy here
    }));

    //console.log("Updated selected designations:", resultdesignations);
    return resultdesignations;
}

  onSubmitDesignation(resultdesignations: any[]) {
    const invalidDesignations = resultdesignations.filter(designation => 
      !designation.designationid || !designation.businessunitid || designation.status <= 0
    );
    
    if (invalidDesignations.length > 0) {
      //console.error("Invalid designations found:", invalidDesignations);
      return;
    }
    this.isLoading = true;
    if (this.selectedBusinessUnitDesignation && resultdesignations.length > 0) {
      //console.log("Submitting result:", resultdesignations); 
      this.service.assignDesignationinsert(resultdesignations).subscribe(
        (res: any) => {
          this.isLoading=false;
          //console.log("Designations assign inserted successfully:", res);
          Swal.fire({
            title: 'Success!',
            text: 'Designations Assign successfully updated!',
            icon: 'success',
            confirmButtonText: 'OK',
          });
          this.designations();
          this.selectedDesignations = []; 
        },
        (error) => {
          this.isLoading=false;
          Swal.fire({
            title: 'Error!',
            text: `Error inserting designations.`,
            icon: 'error',
            confirmButtonText: 'OK',
          });
          //console.error("Error inserting designations:", error);
        }
      );
    } else {
      this.isLoading=false;
      //console.error("Please select a Business Unit and at least one designations.");
      Swal.fire({
        title: 'Error!',
        text: `Please select a Business Unit and at least one designations.`,
        icon: 'error',
        confirmButtonText: 'OK',
      });
    }
  }

  universitys(){
    this.service.getUniversitys().subscribe((res:any)=>{
      this.universityslist = res;
      this.universitySearch = res;
    })
  }
  insertUniversity(): void {
    this.universityForm.markAllAsTouched(); // Mark all form controls as touched to trigger validation messages
    if (this.universityForm.invalid) {
      return; 
    }
  
    const name = this.universityForm.get('name')?.value.toUpperCase();  // Convert name to uppercase
    const formData = new FormData();
    formData.append('name', name);
    formData.append('createdBy', this.empCode);
    formData.append('type', 'UNIVERSITY');
  
    if (this.isEditing) {
      // When editing, confirm with the user if they want to proceed with the update
      Swal.fire({
        title: 'Do you want to update this university?',
        text: `University Name: ${name}`,
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, Update it!',
        cancelButtonText: 'No, Cancel',
        reverseButtons: true
      }).then((result) => {
        if (result.isConfirmed) {
          // If "Yes" is clicked, proceed with the update
          this.isLoading = true;
          const universityId = this.selectedUniversityId;
          const type = 'UNIVERSITY';
          const createdby = this.userData.user.empID;
  
          // Call the service to update the university
          this.service.updateUniversity(universityId, name, createdby, type).subscribe(
            (res: any) => {
              this.isLoading = false;
              if (res.statusCodeValue === 200) {
                this.universitys();  
                this.resetForm(); 
                Swal.fire({
                  title: 'Success!',
                  text: 'University successfully updated!',
                  icon: 'success',
                  confirmButtonText: 'OK',
                });
              } else if (res.statusCodeValue === 400) {
                Swal.fire({
                  title: 'Error!',
                  text: `University with the name '${name}' already exists.`,
                  icon: 'error',
                  confirmButtonText: 'OK',
                });
              }
            },
            (error: any) => {
              this.isLoading = false;
              Swal.fire({
                title: 'Error!',
                text: 'An unexpected error occurred while updating the university, please contact Admin.',
                icon: 'error',
                confirmButtonText: 'OK',
              });
            }
          );
        } else {
          // If "No" is clicked, reset the form and stop the update
          this.resetForm();  // Reset the form when the user cancels the update
        }
      });
    } else {
      // Proceed with the university insertion if it's not an edit
      this.isLoading = true;
      this.service.insertUniversity(formData).subscribe(
        (res: any) => {
          this.isLoading = false;
          if (res.statusCodeValue === 200) {
            this.universitys();  
            this.resetForm();  
            Swal.fire({
              title: 'Success!',
              text: 'University successfully inserted!',
              icon: 'success',
              confirmButtonText: 'OK',
            });
          } else if (res.statusCodeValue === 400) {
            Swal.fire({
              title: 'Error!',
              text: `University with the name '${name}' already exists.`,
              icon: 'error',
              confirmButtonText: 'OK',
            });
          }
        },
        (error: any) => {
          this.isLoading = false;
          Swal.fire({
            title: 'Error!',
            text: 'An unexpected error occurred while inserting the university, please contact Admin.',
            icon: 'error',
            confirmButtonText: 'OK',
          });
        }
      );
    }
  }
  // insertDepartment(): void {
  //   this.departmentForm?.markAllAsTouched();
  //   if (this.departmentForm.invalid) {
  //     return; // Stop if the form is invalid
  //   }
    
  //   const name = this.departmentForm.get('name')?.value.toUpperCase();
  //   const code = this.departmentForm.get('code')?.value.toUpperCase();
  //   const status = this.departmentForm.get('status')?.value;
  
  //   // Prepare data to send in the form
  //   const formData = new FormData();
  //   formData.append('name', name);
  //   formData.append('code', code);
  //   formData.append('status', status);
  //   formData.append('createdby', this.empCode);
  //   formData.append('type', 'DEPARTMENT');
  
  //   // Show confirmation pop-up
  //   Swal.fire({
  //     title: `Are you sure you want to ${this.isDepartment ? 'update' : 'create'} the department?`,
  //     text: `Department Name: ${name}`,
  //     icon: 'warning',
  //     showCancelButton: true,
  //     confirmButtonText: 'Yes',
  //     cancelButtonText: 'No',
  //     reverseButtons: true
  //   }).then((result) => {
  //     if (result.isConfirmed) {
  //       this.isLoading = true;
  
  //       // Proceed with Create or Update based on the flag `isDepartment`
  //       if (this.isDepartment) {
  //         const departmentId = this.selectedDepartmentId;
  //         const modifiedby = this.userData.user.empID;
  //         const type = 'DEPARTMENT';
  
  //         this.service.updateDepartment(departmentId, name, code, status, modifiedby, type).subscribe(
  //           (res: any) => {
  //             this.isLoading = false;
  //             if (res.statusCodeValue === 200) {
  //               Swal.fire({
  //                 title: 'Success!',
  //                 text: 'Department successfully Updated!',
  //                 icon: 'success',
  //                 confirmButtonText: 'OK',
  //               });
  //               this.departments(); // Refresh department list
  //               this.resetFormDepartments(); // Reset form
  //             } else if (res.statusCodeValue === 400) {
  //               Swal.fire({
  //                 title: 'Error!',
  //                 text: `Department with the name '${name}' already exists.`,
  //                 icon: 'error',
  //                 confirmButtonText: 'OK',
  //               });
  //             }
  //           },
  //           (error: any) => {
  //             this.isLoading = false;
  //             Swal.fire({
  //               title: 'Error!',
  //               text: 'An unexpected error occurred while updating the department, please contact Admin.',
  //               icon: 'error',
  //               confirmButtonText: 'OK',
  //             });
  //           }
  //         );
  //       } else {
  //         this.service.insertDepartment(formData).subscribe(
  //           (res: any) => {
  //             this.isLoading = false;
  //             if (res.statusCodeValue === 200) {
  //               Swal.fire({
  //                 title: 'Success!',
  //                 text: 'Department successfully Inserted!',
  //                 icon: 'success',
  //                 confirmButtonText: 'OK',
  //               });
  //               this.departments(); // Refresh department list
  //               this.resetFormDepartments(); // Reset form
  //             } else if (res.statusCodeValue === 400) {
  //               Swal.fire({
  //                 title: 'Error!',
  //                 text: `Department with the name '${name}' already exists.`,
  //                 icon: 'error',
  //                 confirmButtonText: 'OK',
  //               });
  //             } else {
  //               this.isLoading = false;
  //               Swal.fire({
  //                 title: 'Error!',
  //                 text: 'An unexpected error occurred while inserting the department.',
  //                 icon: 'error',
  //                 confirmButtonText: 'OK',
  //               });
  //             }
  //           },
  //           (error: any) => {
  //             this.isLoading = false;
  //             Swal.fire({
  //               title: 'Error!',
  //               text: 'An unexpected error occurred while inserting the department, please contact Admin.',
  //               icon: 'error',
  //               confirmButtonText: 'OK',
  //             });
  //           }
  //         );
  //       }
  //     } else {
  //       // If the user clicked "No", reset the form
  //       this.resetFormDepartments();
  //     }
  //   });
  // }
  
  // insertUniversity(): void {
  //   this.universityForm.markAllAsTouched(); // Marks all form controls as touched to trigger validation messages
  //   if (this.universityForm.invalid) {
  //     //console.log('Form Invalid:', this.universityForm.invalid);
  //     //console.log('Name Touched:', this.universityForm.get('name')?.touched);
  //     //console.log('Name Errors:', this.universityForm.get('name')?.errors);     
  //     return; 
  //   }
  //   this.isLoading = true;
  //   if (this.universityForm.valid) {
  //     const name = this.universityForm.get('name')?.value.toUpperCase();  // Convert name to uppercase
  //     const formData = new FormData();
  //     formData.append('name', name);
  //     formData.append('createdBy', this.empCode);
  //     formData.append('type', 'UNIVERSITY');
  //     if (this.isEditing) {
  //       const universityId = this.selectedUniversityId;
  //       const type='UNIVERSITY';
  //       const createdby=this.userData.user.empID;
  //       this.service.updateUniversity(universityId, name,createdby,type).subscribe(
  //         (res: any) => {
  //           this.isLoading = false;
  //           if(res.statusCodeValue==200){
  //           //console.log('University updated successfully', res);
  //           this.universitys();  
  //           this.resetForm(); 
  //           Swal.fire({
  //             title: 'Success!',
  //             text: 'University successfully updated!',
  //             icon: 'success',
  //             confirmButtonText: 'OK',
  //           });
  //         }else if(res.statusCodeValue==400){
  //           Swal.fire({
  //             title: 'Error!',
  //             text: `University with the name '${name}' already exists.`,
  //             icon: 'error',
  //             confirmButtonText: 'OK',
  //           });
  //         }
  //         (error: any) => {
  //           this.isLoading = false;
  //             Swal.fire({
  //               title: 'Error!',
  //               text: 'An unexpected error occurred while updating the university, please contact Admin.',
  //               icon: 'error',
  //               confirmButtonText: 'OK',
  //             });
  //           }
  //         }
  //       );
  //     } else {
  //       this.service.insertUniversity(formData).subscribe(
  //         (res: any) => {
  //           this.isLoading = false;
  //           if(res.statusCodeValue==200){
  //           //console.log('University inserted successfully', res);
  //           this.universitys();  
  //           this.resetForm();  
  //           Swal.fire({
  //             title: 'Success!',
  //             text: 'University successfully inserted!',
  //             icon: 'success',
  //             confirmButtonText: 'OK',
  //           });
  //         }
  //       else if(res.statusCodeValue==400){
  //         Swal.fire({
  //           title: 'Error!',
  //           text: `University with the name '${name}' already exists.`,
  //           icon: 'error',
  //           confirmButtonText: 'OK',
  //         });
  //       }
  //     },
  //         (error: any) => {
  //           this.isLoading = false;
  //           // Handle error when inserting university (e.g., duplicate error or other server errors)
  //             Swal.fire({
  //               title: 'Error!',
  //               text: 'An unexpected error occurred while inserting the university,please contact Admin.',
  //               icon: 'error',
  //               confirmButtonText: 'OK',
  //             });
  //           }
  //       );
  //     }
  //   } else {
  //     //console.log('Form is not valid');
  //     Swal.fire({
  //       title: 'Error!',
  //       text: 'Form is invalid. Please fill out all required fields.',
  //       icon: 'error',
  //       confirmButtonText: 'OK',
  //     });
  //   }
  // }
  // insertUniversity(): void {
  //   this.universityForm.markAllAsTouched(); // Mark all form controls as touched to trigger validation messages
  //   if (this.universityForm.invalid) {
  //     return; 
  //   }
  
  //   const name = this.universityForm.get('name')?.value.toUpperCase();  // Convert name to uppercase
  //   const formData = new FormData();
  //   formData.append('name', name);
  //   formData.append('createdBy', this.empCode);
  //   formData.append('type', 'UNIVERSITY');
  
  //   if (this.isEditing) {
  //     // When editing, confirm with the user if they want to proceed with the update
  //     Swal.fire({
  //       title: 'Do you want to update this university?',
  //       text: `University Name: ${name}`,
  //       icon: 'warning',
  //       showCancelButton: true,
  //       confirmButtonText: 'Yes, Update it!',
  //       cancelButtonText: 'No, Cancel',
  //       reverseButtons: true
  //     }).then((result) => {
  //       if (result.isConfirmed) {
  //         // If "Yes" is clicked, proceed with the update
  //         this.isLoading = true;
  //         const universityId = this.selectedUniversityId;
  //         const type = 'UNIVERSITY';
  //         const createdby = this.userData.user.empID;
  
  //         // Call the service to update the university
  //         this.service.updateUniversity(universityId, name, createdby, type).subscribe(
  //           (res: any) => {
  //             this.isLoading = false;
  //             if (res.statusCodeValue === 200) {
  //               this.universitys();  
  //               this.resetForm(); 
  //               Swal.fire({
  //                 title: 'Success!',
  //                 text: 'University successfully updated!',
  //                 icon: 'success',
  //                 confirmButtonText: 'OK',
  //               });
  //             } else if (res.statusCodeValue === 400) {
  //               Swal.fire({
  //                 title: 'Error!',
  //                 text: `University with the name '${name}' already exists.`,
  //                 icon: 'error',
  //                 confirmButtonText: 'OK',
  //               });
  //             }
  //           },
  //           (error: any) => {
  //             this.isLoading = false;
  //             Swal.fire({
  //               title: 'Error!',
  //               text: 'An unexpected error occurred while updating the university, please contact Admin.',
  //               icon: 'error',
  //               confirmButtonText: 'OK',
  //             });
  //           }
  //         );
  //       } else {
  //         // If "No" is clicked, reset the form and stop the update
  //         this.isEditing = false;
  //       }
  //     });
  //   } else {
  //     // Proceed with the university insertion if it's not an edit
  //     this.isLoading = true;
  //     this.service.insertUniversity(formData).subscribe(
  //       (res: any) => {
  //         this.isLoading = false;
  //         if (res.statusCodeValue === 200) {
  //           this.universitys();  
  //           this.resetForm();  
  //           Swal.fire({
  //             title: 'Success!',
  //             text: 'University successfully inserted!',
  //             icon: 'success',
  //             confirmButtonText: 'OK',
  //           });
  //         } else if (res.statusCodeValue === 400) {
  //           Swal.fire({
  //             title: 'Error!',
  //             text: `University with the name '${name}' already exists.`,
  //             icon: 'error',
  //             confirmButtonText: 'OK',
  //           });
  //         }
  //       },
  //       (error: any) => {
  //         this.isLoading = false;
  //         Swal.fire({
  //           title: 'Error!',
  //           text: 'An unexpected error occurred while inserting the university, please contact Admin.',
  //           icon: 'error',
  //           confirmButtonText: 'OK',
  //         });
  //       }
  //     );
  //   }
  // }
  // insertDepartment(): void {
  //   this.departmentForm?.markAllAsTouched();
  //   if (this.departmentForm.invalid) {
  //    // console.log('Form Invalid:', this.departmentForm.invalid);
  //     //console.log('Name Touched:', this.departmentForm.get('name')?.touched);
  //     //console.log('Name Errors:', this.departmentForm.get('name')?.errors);
  //     return;
  //   }
  //   this.isLoading = true;
  //   if (this.departmentForm.valid) {
  //     const name = this.departmentForm.get('name')?.value.toUpperCase();
  //     const code = this.departmentForm.get('code')?.value.toUpperCase();
  //     const status = this.departmentForm.get('status')?.value;
  //     const formData = new FormData();
  //     formData.append('name', name);
  //     formData.append('code', code);
  //     formData.append('status', status);
  //     formData.append('createdby', this.empCode);
  //     formData.append('type', 'DEPARTMENT');
  //     if (this.isDepartment) {
  //       const departmentId = this.selectedDepartmentId;
  //       const modifiedby = this.userData.user.empID;
  //       const type='DEPARTMENT';
  //       this.service.updateDepartment(departmentId, name, code, status,modifiedby,type).subscribe(
  //         (res: any) => {
  //           this.isLoading = false;
  //           if(res.statusCodeValue==200){
  //           //console.log('Department updated successfully', res);
  //           Swal.fire({
  //             title: 'Success!',
  //             text: 'Department successfully Updated!',
  //             icon: 'success',
  //             confirmButtonText: 'OK',
  //           });
  //           this.departments();
  //           this.resetFormDepartments();
  //         }else if(res.statusCodeValue==400){
  //           Swal.fire({
  //             title: 'Error!',
  //             text: `Department with the name '${name}' already exists.`,
  //             icon: 'error',
  //             confirmButtonText: 'OK',
  //           });
  //         }
  //         },
  //         (error: any) => {
  //           this.isLoading = false;
  //           Swal.fire({
  //             title: 'Error!',
  //             text: 'An unexpected error occurred while updating the department, please contact Admin.',
  //             icon: 'error',
  //             confirmButtonText: 'OK',
  //           });
  //         }
  //       );
  //     } else {
  //       this.service.insertDepartment(formData).subscribe(
  //         (res: any) => {
  //           this.isLoading = false;
  //           //console.log('Response received:', res); 
  //           if (res.statusCodeValue === 200) {
  //            // console.log('Department inserted successfully', res);
  //             Swal.fire({
  //               title: 'Success!',
  //               text: 'Department successfully Inserted!',
  //               icon: 'success',
  //               confirmButtonText: 'OK',
  //             });
  //           } 
  //           else if (res.statusCodeValue === 400) {
  //             this.isLoading = false;
  //            // console.log('Error: Department already exists');
  //             Swal.fire({
  //               title: 'Error!',
  //               text: `Department with the name '${name}' already exists.`,
  //               icon: 'error',
  //               confirmButtonText: 'OK',
  //             });
  //           } 
  //           else {
  //             //console.log('Unknown error during insertion:', res);
  //             this.isLoading=false;
  //             Swal.fire({
  //               title: 'Error!',
  //               text: 'An unexpected error occurred while inserting the department.',
  //               icon: 'error',
  //               confirmButtonText: 'OK',
  //             });
  //           }
  //           this.departments();
  //           this.resetFormDepartments();
  //         },
  //         (error: any) => {
  //           this.isLoading = false;
  //           //console.log('Error while inserting department:', error);
  //           Swal.fire({
  //             title: 'Error!',
  //             text: 'An unexpected error occurred while inserting the department, please contact Admin.',
  //             icon: 'error',
  //             confirmButtonText: 'OK',
  //           });
  //         }
  //       );
  //     }
  //   } else {
  //     //console.log('Form is not valid');
  //     this.isLoading = false;
  //     Swal.fire({
  //       title: 'Error!',
  //       text: 'Form is invalid. Please fill out all required fields.',
  //       icon: 'error',
  //       confirmButtonText: 'OK',
  //     });
  //   }
  // }
  
// insertDesignation(): void {
//   this.designationForm?.markAllAsTouched();
//   if (this.designationForm.invalid) {
//     //console.log('Form Invalid:', this.designationForm.invalid);
//     //console.log('Name Touched:', this.designationForm.get('name')?.touched);
//     //console.log('Name Errors:', this.designationForm.get('name')?.errors);
//     return;
//   }

//   this.isLoading = true;
//   if (this.designationForm.valid) {
//     const name = this.designationForm.get('name')?.value.toUpperCase();  // Ensure the name is uppercase
//     const code = this.designationForm.get('code')?.value.toUpperCase(); // Ensure the code is uppercase
//     const status = this.designationForm.get('status')?.value;
//     const formData = new FormData();
//     formData.append('name', name);
//     formData.append('code', code);
//     formData.append('status', status);
//     formData.append('createdby', this.empCode);
//     formData.append('type', 'DESIGNATION');
//     if (this.isDesignation) {
//       const designationId = this.selectedDesignationId;
//       const modifiedby = this.userData.user.empID;
//       const type='DESIGNATION'
//       this.service.updateDesignation(designationId, name, code, status, modifiedby,type).subscribe((res: any) => {
//         this.isLoading = false;
//         if (res.statusCodeValue == 200) {
//           Swal.fire({
//             title: 'Success!',
//             text: 'Designation successfully Updated!',
//             icon: 'success',
//             confirmButtonText: 'OK',
//           });
//         } else if (res.statusCodeValue == 400) {
//           Swal.fire({
//             title: 'Error!',
//             text: `Designation with the name '${name}' already exists.`,
//             icon: 'error',
//             confirmButtonText: 'OK',
//           });
//         } else {
//           Swal.fire({
//             title: 'Error!',
//             text: 'An unexpected error occurred while updating the designation.',
//             icon: 'error',
//             confirmButtonText: 'OK',
//           });
//         }
//         this.designations();  
//         this.resetFormDesignation();
//       });

//     } else {
//       this.service.insertDesignation(formData).subscribe((res: any) => {
//         this.isLoading = false;
//         if (res.statusCodeValue == 200) {
//           Swal.fire({
//             title: 'Success!',
//             text: 'Designation successfully Inserted!',
//             icon: 'success',
//             confirmButtonText: 'OK',
//           });
//         } else if (res.statusCodeValue == 400) {
//           Swal.fire({
//             title: 'Error!',
//             text: `Designation with the name '${name}' already exists.`,
//             icon: 'error',
//             confirmButtonText: 'OK',
//           });
//         } else {
//           Swal.fire({
//             title: 'Error!',
//             text: 'An unexpected error occurred while inserting the designation.',
//             icon: 'error',
//             confirmButtonText: 'OK',
//           });
//         }
//         this.designations(); 
//         this.resetFormDesignation();
//       });
//     }
//   } else {
//     Swal.fire({
//       title: 'Error!',
//       text: 'Form is not valid',
//       icon: 'error',
//       confirmButtonText: 'OK',
//     });
//   }
// }
insertDepartment(): void {
  this.departmentForm?.markAllAsTouched();
  if (this.departmentForm.invalid) {
    return; // Stop if the form is invalid
  }
  
  const name = this.departmentForm.get('name')?.value.toUpperCase();
  const code = this.departmentForm.get('code')?.value.toUpperCase();
  const status = this.departmentForm.get('status')?.value;

  // Prepare data to send in the form
  const formData = new FormData();
  formData.append('name', name);
  formData.append('code', code);
  formData.append('status', status);
  formData.append('createdby', this.empCode);
  formData.append('type', 'DEPARTMENT');

  // Proceed directly if it's a new department (no confirmation needed)
  if (!this.isDepartment) {
    this.isLoading = true;

    this.service.insertDepartment(formData).subscribe(
      (res: any) => {
        this.isLoading = false;
        if (res.statusCodeValue === 200) {
          Swal.fire({
            title: 'Success!',
            text: 'Department successfully Inserted!',
            icon: 'success',
            confirmButtonText: 'OK',
          });
          this.departments(); // Refresh department list
          this.resetFormDepartments(); // Reset form
        } else if (res.statusCodeValue === 400) {
          Swal.fire({
            title: 'Error!',
            text: `Department with the name '${name}' already exists.`,
            icon: 'error',
            confirmButtonText: 'OK',
          });
        } else {
          this.isLoading = false;
          Swal.fire({
            title: 'Error!',
            text: 'An unexpected error occurred while inserting the department.',
            icon: 'error',
            confirmButtonText: 'OK',
          });
        }
      },
      (error: any) => {
        this.isLoading = false;
        Swal.fire({
          title: 'Error!',
          text: 'An unexpected error occurred while inserting the department, please contact Admin.',
          icon: 'error',
          confirmButtonText: 'OK',
        });
      }
    );
  } else {
    // Show confirmation pop-up only when updating an existing department
    Swal.fire({
      title: `Are you sure you want to update the department?`,
      text: `Department Name: ${name}`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes',
      cancelButtonText: 'No',
      reverseButtons: true
    }).then((result) => {
      if (result.isConfirmed) {
        this.isLoading = true;

        // Proceed with Update
        const departmentId = this.selectedDepartmentId;
        const modifiedby = this.userData.user.empID;
        const type = 'DEPARTMENT';
    
        this.service.updateDepartment(departmentId, name, code, status, modifiedby, type).subscribe(
          (res: any) => {
            this.isLoading = false;
            if (res.statusCodeValue === 200) {
              Swal.fire({
                title: 'Success!',
                text: 'Department successfully Updated!',
                icon: 'success',
                confirmButtonText: 'OK',
              });
              this.departments(); // Refresh department list
              this.resetFormDepartments(); // Reset form
            } else if (res.statusCodeValue === 400) {
              Swal.fire({
                title: 'Error!',
                text: `Department with the name '${name}' already exists.`,
                icon: 'error',
                confirmButtonText: 'OK',
              });
            }
          },
          (error: any) => {
            this.isLoading = false;
            Swal.fire({
              title: 'Error!',
              text: 'An unexpected error occurred while updating the department, please contact Admin.',
              icon: 'error',
              confirmButtonText: 'OK',
            });
          }
        );
      } else {
        // If the user clicked "No", reset the form
        this.resetFormDepartments();
      }
    });
  }
}

insertDesignation(): void {
  this.designationForm?.markAllAsTouched();
  if (this.designationForm.invalid) {
    return; // Stop if the form is invalid
  }

  const name = this.designationForm.get('name')?.value.toUpperCase(); // Ensure the name is uppercase
  const code = this.designationForm.get('code')?.value.toUpperCase(); // Ensure the code is uppercase
  const status = this.designationForm.get('status')?.value;

  const formData = new FormData();
  formData.append('name', name);
  formData.append('code', code);
  formData.append('status', status);
  formData.append('createdby', this.empCode);
  formData.append('type', 'DESIGNATION');

  // If it's not an update, submit the form directly (no confirmation pop-up)
  if (!this.isDesignation) {
    this.isLoading = true;

    this.service.insertDesignation(formData).subscribe(
      (res: any) => {
        this.isLoading = false;
        if (res.statusCodeValue === 200) {
          Swal.fire({
            title: 'Success!',
            text: 'Designation successfully Inserted!',
            icon: 'success',
            confirmButtonText: 'OK',
          });
          this.designations(); // Refresh designation list
          this.resetFormDesignation(); // Reset form
        } else if (res.statusCodeValue === 400) {
          Swal.fire({
            title: 'Error!',
            text: `Designation with the name '${name}' already exists.`,
            icon: 'error',
            confirmButtonText: 'OK',
          });
        } else {
          Swal.fire({
            title: 'Error!',
            text: 'An unexpected error occurred while inserting the designation.',
            icon: 'error',
            confirmButtonText: 'OK',
          });
        }
      },
      (error: any) => {
        this.isLoading = false;
        Swal.fire({
          title: 'Error!',
          text: 'An unexpected error occurred while inserting the designation, please contact Admin.',
          icon: 'error',
          confirmButtonText: 'OK',
        });
      }
    );
  } else {
    // Show confirmation pop-up only when updating the designation
    Swal.fire({
      title: `Are you sure you want to update the designation?`,
      text: `Designation Name: ${name}`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes',
      cancelButtonText: 'No',
      reverseButtons: true
    }).then((result) => {
      if (result.isConfirmed) {
        this.isLoading = true;

        // Proceed with Update
        const designationId = this.selectedDesignationId;
        const modifiedby = this.userData.user.empID;
        const type = 'DESIGNATION';

        this.service.updateDesignation(designationId, name, code, status, modifiedby, type).subscribe(
          (res: any) => {
            this.isLoading = false;
            if (res.statusCodeValue === 200) {
              Swal.fire({
                title: 'Success!',
                text: 'Designation successfully Updated!',
                icon: 'success',
                confirmButtonText: 'OK',
              });
              this.designations(); // Refresh designation list
              this.resetFormDesignation(); // Reset form
            } else if (res.statusCodeValue === 400) {
              Swal.fire({
                title: 'Error!',
                text: `Designation with the name '${name}' already exists.`,
                icon: 'error',
                confirmButtonText: 'OK',
              });
            }
          },
          (error: any) => {
            this.isLoading = false;
            Swal.fire({
              title: 'Error!',
              text: 'An unexpected error occurred while updating the designation, please contact Admin.',
              icon: 'error',
              confirmButtonText: 'OK',
            });
          }
        );
      } else {
        // If the user clicked "No", reset the form
        this.resetFormDesignation();
      }
    });
  }
}


  editDesignation(designationid: any, name: any, code: any, status: any): void {
    //alert(designationid + "-" + name + "-" + code + "-" + status);
    this.selectedDesignationId = designationid;
    this.selectedDesignationName = name;
    this.selectedDesignationCode = code;
    this.selectedDesignationStatus = status;
    this.isDesignation = true;
    this.designationForm.get('name')?.setValue(name);
    this.designationForm.get('code')?.setValue(code);
    this.designationForm.get('status')?.setValue(status);
  }
  editDepartment(parentdepartmentid: any, name: any, code: any, status: any,departmentid:any): void {
    //alert(departmentid + "-" + name + "-" + code + "-" + status);

    this.selectedDepartmentId = parentdepartmentid+","+departmentid;
    this.selectedDepartmentName = name;
    this.selectedDepartmentCode = code;
    this.selectedDepartmentStatus = status;
    this.isDepartment = true;
    this.departmentForm.get('name')?.setValue(name);
    this.departmentForm.get('code')?.setValue(code);
    this.departmentForm.get('status')?.setValue(status);
  }
  resetFormDesignation(): void {
    this.isDesignation = false;
    this.selectedDesignationId = null;
    this.selectedDesignationName = null;
    this.selectedDesignationCode = null;
    this.selectedDesignationStatus = null;
    this.designationForm.reset();
  }
  resetFormDepartments(): void {
    this.isDepartment = false;
    this.selectedDepartmentId = null;
    this.selectedDepartmentName = null;
    this.selectedDepartmentCode = null;
    this.selectedDepartmentStatus = null;
    this.departmentForm.reset();
  }
  editUniversity(UNIVERSITYID:any,universityname:string){
    //alert(UNIVERSITYID+"--"+universityname);
    this.selectedUniversityName = universityname;
    this.selectedUniversityId=UNIVERSITYID;
    this.isEditing = true;
    this.universityForm.get('name')?.setValue(universityname);
    // this.universitycheck=true;
  }
  // resetForm() {
  //   this.isEditing = false;
  //   this.selectedUniversityName = null;  
  //   this.universityForm.reset();  
  // }
  resetForm(): void {
    this.universityForm.reset(); // Resets all form controls to their initial state
    this.isEditing = false; // Clear the editing state
    this.selectedUniversityId = null; // Clear the selected university ID
    this.selectedUniversityName = ''; // Clear the selected university name
  }

  cancelEdit() {
    this.resetForm();
    this.resetFormDesignation();
  }
  applySearchFilter() {
    if (!this.searchTermUniversity) {
      this.universityslist = this.universitySearch;
      return;
    }
    this.universityslist = this.universitySearch.filter((item: any) => {
      const dataString = JSON.stringify(item).toLowerCase();
      const searchTermLowerCase = this.searchTermUniversity.toLowerCase();
      return (
        dataString.includes(searchTermLowerCase) 
      );
    });
}
restrictInput(event: any): void {
  const inputField = event.target as HTMLInputElement;
  const currentValue = inputField.value;
  inputField.value = currentValue.replace(/[^a-zA-Z\s]/g, '');
  this.searchTermUniversity = inputField.value;
}

applySearchFilterDepartment() {
  if (!this.searchTermDepartment) {
    this.departmentslist = this.departmentSearch;
    return;
  }
  const searchTermLowerCase = this.searchTermDepartment.toLowerCase();
  this.departmentslist = this.departmentSearch.filter((item: any) => {
    return (
      item.NAME.toLowerCase().includes(searchTermLowerCase) ||
      item.code.toLowerCase().includes(searchTermLowerCase)
    );
  });
  this.searchTermDepartment = '';
}

applySearchDesignation() {
  if (!this.searchTermDesignation) {
    this.designationslist = this.designationSearch;
    return;
  }
  
  this.designationslist = this.designationSearch.filter((item: any) => {
    const dataString = JSON.stringify(item).toLowerCase();
    const searchTermLowerCase = this.searchTermDesignation.toLowerCase();
    return (
      dataString.includes(searchTermLowerCase) 
    );
  });
  this.searchTermDesignation = '';
}
applySearchDesignationassign(){
  if (!this.searchTerms) {
    this.designationslists = this.designationSearchAssign;
    return;
  }
  this.designationslists = this.designationSearchAssign.filter((item: any) => {
    const dataString = JSON.stringify(item).toLowerCase();
    const searchTermLowerCase = this.searchTerms.toLowerCase();
    return (
      dataString.includes(searchTermLowerCase) 
    );
  });
  this.searchTerms = '';
}
applySearchFilterDepartmentAssign(){
if (!this.searchTermAssignDepartment) {
  this.departmentslists = this.departmentassignSearch;
  return;
}
const searchTermLowerCase = this.searchTermAssignDepartment.toLowerCase();
this.departmentslists = this.departmentassignSearch.filter((item: any) => {
  return (
    item.NAME.toLowerCase().includes(searchTermLowerCase) ||
    item.code.toLowerCase().includes(searchTermLowerCase)
  );
});
this.searchTermAssignDepartment = '';

}
convertToUpperCase(event: any): void {
  const inputField = event.target;
  inputField.value = inputField.value.toUpperCase(); 
}
// allowOnlyLettersAndSpaces(event: KeyboardEvent) {
//   const charCode = event.key;
//   if (!/^[a-zA-Z\s]*$/.test(charCode)) {
//     event.preventDefault(); 
//   }
// }
allowOnlyLettersAndSpaces(event: KeyboardEvent) {
  const charCode = event.key;
  const inputField = event.target as HTMLInputElement;
  const inputValue = inputField.value;
  if (charCode === " " && inputValue.length === 0) {
    event.preventDefault();
  } else if (!/^[a-zA-Z\s]*$/.test(charCode)) {
    event.preventDefault();
  }
}

onCopy(event: ClipboardEvent) {
  event.preventDefault(); 
}

onPaste(event: ClipboardEvent) {
  event.preventDefault(); 
}
resetFormAndFilters(): void {
  this.searchTermUniversity = '';
  this.universitys(); 
  this.searchTermDesignation='';
  this.designations();
  this.searchTermDepartment=''; 
  this.departments();
  this.searchTermAssignDepartment='';
  this.departments();

}

}
